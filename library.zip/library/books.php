<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Home</title>
    <link rel="stylesheet" href="bootstrap-starter/assets/bootstrap.min.css">
    <script src="bootstrap-starter/assets/bootstrap.min.js"></script>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php
include_once "header.php";
?>
<div class="container">
    <div class="table-responsive-sm">
<table class="table table-hover ">
<thead>
<tr class="table-active">
    <th scope="col">Num.</th>
    <th scope="col">Name</th>
    <th scope="col">Catagory</th>
    <th scope="col">Edition</th>
    <th scope="col">Author</th>
    <th scope="col">Publisher</th>
    <th scope="col">Count</th>
    <th scope="col">Edit</th>
    <th scope="col">Delet</th>
    <th scope="col">Borrow</th>

</tr>
</thead>
    <tbody>
    <tr>
        <th scope="col">1</th>
        <td>Html5</td>
        <td>web</td>
        <td>second</td>
        <td>Simon</td>
        <td>oraly</td>
        <td>3</td>
        <td>Edit</td>
        <td>Delete</td>
        <td>Borrow</td>

    </tr>
    <tr>
        <th scope="col">1</th>
        <td>Html5</td>
        <td>web</td>
        <td>second</td>
        <td>Simon</td>
        <td>oraly</td>
        <td>3</td>
        <td>Edit</td>
        <td>Delete</td>
        <td>Borrow</td>

    </tr>
    <tr>
        <th scope="col">1</th>
        <td>Html5</td>
        <td>web</td>
        <td>second</td>
        <td>Simon</td>
        <td>oraly</td>
        <td>3</td>
        <td>Edit</td>
        <td>Delete</td>
        <td>Borrow</td>

    </tr>
    <tr>
        <th scope="col">1</th>
        <td>Html5</td>
        <td>web</td>
        <td>second</td>
        <td>Simon</td>
        <td>oraly</td>
        <td>3</td>
        <td>Edit</td>
        <td>Delete</td>
        <td>Borrow</td>

    </tr>
    <tr>
        <th scope="col">1</th>
        <td>Html5</td>
        <td>web</td>
        <td>second</td>
        <td>Simon</td>
        <td>oraly</td>
        <td>3</td>
        <td>Edit</td>
        <td>Delete</td>
        <td>Borrow</td>

    </tr>
    <tr>
        <th scope="col">1</th>
        <td>Html5</td>
        <td>web</td>
        <td>second</td>
        <td>Simon</td>
        <td>oraly</td>
        <td>3</td>
        <td>Edit</td>
        <td>Delete</td>
        <td>Borrow</td>

    </tr>


    </tbody>
</table>
    </div>
    <form action="#">
        <div class="form-group">
            <label for="add" class="text-info">For add new book pleas click here</label>
            <input type="submit" class="btn btn-success" value="Add">
        </div>
    </form>
</div>














<?php
include_once "footer.php";
?>
</body>
</html>