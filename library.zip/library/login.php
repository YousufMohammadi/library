<?php
/**
 * Created by PhpStorm.
 * User: Mh.Yousuf
 * Date: 8/23/2021
 * Time: 9:35 AM
 */
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>login</title>
    <link rel="stylesheet" href="bootstrap-starter/assets/bootstrap.min.css">
    <script src="bootstrap-starter/assets/bootstrap.min.js"></script>
    <link rel="stylesheet" href="css/style.css">
</head>
<body class="back">
<div class="container mt-5 text-center  logcontainer">
    <form action="#" class="border border-white border-primary w-50">
        <div class="form-group">
            <label for="email">Email:</label>
            <input type="text" placeholder="Enter Your Email" class="w-50 p-2 text-center text-white bg-dark loginform">
        </div>
        <div class="form-group">
            <label for="email" >Password:</label>
            <input type="password" placeholder="Enter Your Password" class="mr-4 w-50 p-2 text-center text-white bg-dark">
        </div>
        <div class="form-group">

            <input type="submit" value="Login" class="btn btn-success">
            <input type="reset" value="Cancel" class="btn btn-danger">
        </div>
        <hr class="w-50">
        <div class="form-group">
            <a href="#" class="text-white">forgot password</a><br>
            <a href="#" class="text-white">sign up</a>
        </div>
    </form>
</div>

</body>
</html>
