<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Home</title>
    <link rel="stylesheet" href="bootstrap-starter/assets/bootstrap.min.css">
    <script src="bootstrap-starter/assets/bootstrap.min.js"></script>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php
include_once "header.php";
?>
<div class="container">
    <div class="table-responsive-sm">
        <table class="table table-hover ">
            <thead>
            <tr class="table-active">
                <th scope="col">Num.</th>
                <th scope="col">Name</th>
                <th scope="col">Age</th>
                <th scope="col">lastName</th>
                <th scope="col">Salary</th>
                <th scope="col">Department</th>
                <th scope="col">Edit</th>
                <th scope="col">Delete</th>


            </tr>
            </thead>
            <tbody>
            <tr>
                <th scope="col">1</th>
                <td>Ali</td>
                <td>25</td>
                <td>Mohammadi</td>
                <td>25000</td>
                <td>SF</td>
                <td>edit</td>
                <td>delete</td>
            </tr>
            <tr>
                <th scope="col">1</th>
                <td>Ali</td>
                <td>25</td>
                <td>Mohammadi</td>
                <td>25000</td>
                <td>SF</td>
                <td>edit</td>
                <td>delete</td>
            </tr>
            <tr>
                <th scope="col">1</th>
                <td>Ali</td>
                <td>25</td>
                <td>Mohammadi</td>
                <td>25000</td>
                <td>SF</td>
                <td>edit</td>
                <td>delete</td>
            </tr>
            <tr>
                <th scope="col">1</th>
                <td>Ali</td>
                <td>25</td>
                <td>Mohammadi</td>
                <td>25000</td>
                <td>SF</td>
                <td>edit</td>
                <td>delete</td>
            </tr>
            <tr>
                <th scope="col">1</th>
                <td>Ali</td>
                <td>25</td>
                <td>Mohammadi</td>
                <td>25000</td>
                <td>SF</td>
                <td>edit</td>
                <td>delete</td>
            </tr>
            <tr>
                <th scope="col">1</th>
                <td>Ali</td>
                <td>25</td>
                <td>Mohammadi</td>
                <td>25000</td>
                <td>SF</td>
                <td>edit</td>
                <td>delete</td>
            </tr>



            </tbody>
        </table>
    </div>
    <form action="#">
        <div class="form-group">
            <label for="add" class="text-info">For add new Teachers pleas click here</label>
            <input type="submit" class="btn btn-success" value="Add">
        </div>
    </form>
</div>
<?php
include_once "footer.php";
?>
</body>
</html>