<?php
/**
 * Created by PhpStorm.
 * User: Mh.Yousuf
 * Date: 8/22/2021
 * Time: 12:01 PM
 */
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="bootstrap-starter/assets/font-awesome.css">
</head>
<body>

<div class="row bg-warning fixed-bottom text-white">
    <div class="col-12  p-3  text-center">
        &copy;<?php echo date("Y");?>
    </div>

</body>
</html>
