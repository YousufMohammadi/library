<?php
/**
 * Created by PhpStorm.
 * User: Mh.Yousuf
 * Date: 8/22/2021
 * Time: 12:01 PM
 */
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-warning fixed-top">
    <div  class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">

            <li class="nav-item">
                <a href="index.php" class="nav-link text-danger">Home</a>
            </li>
            <li class="nav-item">
                <a href="books.php" class="nav-link text-white">Books</a>
            </li>
            <li class="nav-item">
                <a href="borrowers.php" class="nav-link text-white">Bowrowers</a>
            </li>
            <li class="nav-item">
                <a href="students.php" class="nav-link text-white">Students</a>
            </li>
            <li class="nav-item">
                <a href="teachers.php" class="nav-link text-white">Teachers</a>
            </li>
            <li class="nav-item">
                <a href="users.php" class="nav-link text-white">Users</a>
            </li>
            <li class="nav-item">
                <a href="signup.php" class="nav-link text-white">Sign Up</a>
            </li>
            <li class="nav-item">
                <a href="login.php" class="nav-link text-white">Login</a>
            </li>

        </ul>
        <form class="form-inline my-2 my-lg-0">
            <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
            <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
        </form>
    </div>

</nav>

</body>
</html>
