<?php
/**
 * Created by PhpStorm.
 * User: Mh.Yousuf
 * Date: 8/26/2021
 * Time: 8:08 AM
 */
?>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$db = "library";
// Create connection
$conn = mysqli_connect("$servername","$username","$password","$db");

// Check connection
if (!$conn) {
    die("Connection failed: " . $conn->connect_error);
}else{

    echo "Connected successfully";
}
?>
