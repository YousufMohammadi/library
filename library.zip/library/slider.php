<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Home</title>
    <link rel="stylesheet" href="bootstrap-starter/assets/bootstrap.min.css">
    <script src="bootstrap-starter/assets/bootstrap.min.js"></script>
</head>
<body>
<div class="container">
    <?php
    include_once "header.php";
    ?>
    <div class="row mt-5 ">
        <div class="col-lg-4">
            <div class="card" style="width: 18rem;">
                <img class="card-img-top" src="img/%20%20(1).jpg" alt="Card image cap">
                <div class="card-body">
                    <p class="card-text">100 Teachers</p>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="card" style="width: 18rem;">
                <img class="card-img-top" src="img/%20%20(2).jpg" alt="Card image cap">
                <div class="card-body">
                    <p class="card-text">100 Books</p>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="card" style="width: 18rem;">
                <img class="card-img-top" src="img/%20%20(3).jpg" alt="Card image cap">
                <div class="card-body">
                    <p class="card-text">100 Students</p>
                </div>
            </div>
        </div>
    </div>
    <div class="row mt-5 mb-5">
        <div class="col-lg-4">
            <div class="card" style="width: 18rem;">
                <img class="card-img-top" src="img/%20%20(4).jpg" alt="Card image cap">
                <div class="card-body">
                    <p class="card-text">10 Users</p>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="card" style="width: 18rem;">
                <img class="card-img-top" src="img/%20%20(12).jpg" alt="Card image cap">
                <div class="card-body">
                    <p class="card-text">100 Borrowers</p>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="card" style="width: 18rem;">
                <img class="card-img-top" src="img/%20%20(8).jpg" alt="Card image cap">
                <div class="card-body">
                    <p class="card-text">100 Categories</p>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <img src="img/%20%20(7).jpg" class="img-fluid" alt="Responsive image">
        </div>
    </div>

</div>

</body>
</html>